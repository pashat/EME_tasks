<div class="showhide">
    <p><strong>Show/Hide:</strong>
        <a href="javascript:void(0)" onclick="showHide();">birth rate|</a>
        <a href="javascript:void(0)" onclick="showHideClass();">cellphones|</a>
        <a href="javascript:void(0)" onclick="showHide();">children/ woman|</a>
        <a href="javascript:void(0)" onclick="showHide();">electric usage|</a>
        <a href="javascript:void(0)" onclick="showHide();">internet usage</a>
    </p>
</div>