<!DOCTYPE html>
<html lang="de">
<head>
    <?php include("head.php"); ?>
</head>

<body>
<?php include("navi.php"); ?>
<div class="container">
    <?php
    include("ipsum.php");
    include ("showhide.php");
    include("table.php");
    include("footer.php");
    ?>
</div>
</body>
</html>