<header class="sticky" >
    <nav>
        <a class="logo" href="index.php">world_data</a>
        <ul id="main_nav" class="box">
            <li>
                <a href="index.php"><i class="fa fa-list-ul"></i>A1 - Table</a>
            </li>
            <li>
                <a href="parse.php"><i class="fa fa-list-ul"></i>A2 - Parse</a>
            </li>
            <li>
                <a href="save.php"><i class="fa fa-list-ul"></i>A2 - Save</a>
            </li>
            <li>
                <a href="print.php"><i class="fa fa-list-ul"></i>A2 - Print</a>
            </li>
            <li>
                <a href=""><i class="fa fa-list-ul"></i>A3 - REST</a>
            </li>
            <li>
                <a href=""><i class="fa fa-list-ul"></i>A4 - Vis</a>
            </li>
        </ul>
    </nav>
</header>