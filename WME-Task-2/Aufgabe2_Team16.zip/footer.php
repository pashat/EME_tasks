<div class="container">
    <p>
        <span style="float: left">Copyright <i class="fa fa-copyright"></i> 2018 world_data</span>
        <span style="float: right">This solution has been created by:</span>
    </p>
    <br>
    <span style="float: left">Second course exercise <strong>XML und PHP</strong> of the lecture Web and Multimedia Engineering</span>
    <span style="float: right">Team 16</span>
</div>