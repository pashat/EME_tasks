    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>world_data</title>
    <meta name="description" content="WME Second course exercise XML und PHP">
    <meta name="author" content="WME_team16">
    <meta name="keywords" content="World,Data,HTML,HTML5,JavaScript,CSS,CSS3, XML, PHP">

    <link rel="stylesheet" href="reset.css" type="text/css" >

    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="show_hide.js"></script>
    <script src="sort_table.js"></script>