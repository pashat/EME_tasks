alert("No ajax calls implemented ;)");
